# Table V Computation-Cost Benchmark

Source: `SCAPE_ZK_updated.pdf`, Table V, "Authorization Verification Scalability".

This folder contains code and generated artifacts for computation-cost comparison using only the schemes and terms shown in Table V.

Generated files:

- `table_v_cost_components.csv`
- `table_v_total_cost_vs_requests.svg`
- `table_v_cost_breakdown_100req.svg`
- `generate_table_v_cost_graphs.py`

Primitive calibration:

- `T_zk^v`: 12.3335 ms, from `paper/results/groth16_bench.csv` request verification rows.
- `T_pair`: 30.5452 ms, from `paper/results/bls_bench.csv` `pairing_only` rows.
- `T_grp`: 5.1768 ms, derived from BLS aggregate verification residual `(verify_agg - T_pair) / n`.
- `T_hash`: 0.00037800 ms, local SHA-256 metadata-leaf calibration.

Modeled Table V formulas:

- XAuth [6]: off-chain `n*T_zk^v`; on-chain `n*T_hash`.
- SSL-XIoMT [8]: off-chain `n*T_zk^v`; on-chain `n*T_hash`.
- Scheme [30]: off-chain `T_zk^v + T_pair + n*T_grp`; on-chain `n*T_hash`.
- SCAPE-ZK: off-chain `n*T_zk^v`; on-chain `T_pair`.

Scope note:

This is a Table-V-term computation-cost benchmark/estimator. It is not a full integrated end-to-end benchmark and does not add operations outside Table V.
